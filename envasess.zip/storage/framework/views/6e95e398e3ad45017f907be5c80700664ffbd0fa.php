<footer class="footer_area">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="footer_widget">
                    <h4 class="widget_title">Our Contacts</h4>
                    <div class="footer_widget_content para_default">
                        <ul class="contact_info">
                            <li><span class="icon flaticon-phone-call"></span> +254 722 347155</li>
                            <li><span class="icon flaticon-contact"></span> info@envasses.org</li>
                            <li><span class="icon flaticon-placeholder-outline"></span>Ralli House Building, 1st Floor.
                                 P. O Box 2013 - 80100 Mombasa, Kenya.</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="footer_widget">
                    <h4 class="widget_title">About us</h4>
                    <div class="footer_widget_content para_default">
                        <ul>
 <?php $__empty_1 = true; $__currentLoopData = $aboutsHome; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li><a href="<?php echo e(route('about.show',$a->slug)); ?>"><?php echo e($a->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li><a href="#">Oops sorry!</a></li>
                                <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="footer_widget">
                    <h4 class="widget_title">Our Services</h4>
                    <div class="footer_widget_content para_default">
                        <ul>
                            <?php $__empty_1 = true; $__currentLoopData = $servicesHome; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li><a href="<?php echo e(route('services.show',$s->slug)); ?>"><?php echo e($s->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li><a href="<?php echo e(route('services.show',$s->slug)); ?>">Oops sorry!</a></li>
                                <?php endif; ?>
                           
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="footer_widget">
                    <h4 class="widget_title">Newsletter</h4>
                    <ul class="footer_social_icon">
                        <li>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-pinterest-p"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-youtube"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer_bottom text-center">
        <div class="container">
            <p>© Copyright 2019 <span>|</span> <a href="/"> ENVASSES CONSULTANTS</a> <span>|</span> All Rights Reserved
            </p>
        </div>
    </div>
</footer>
<?php /**PATH /home/morlex/Documents/envasses/resources/views/layouts/footer.blade.php ENDPATH**/ ?>